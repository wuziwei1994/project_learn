def getName(stcStr):
    return stcStr.split(',')[-2][12:]
print(getName('A old lady come in, the name is Mary, level 94454'))